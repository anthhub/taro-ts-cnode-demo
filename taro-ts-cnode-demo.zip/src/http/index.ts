import user from './api/user'
import topic from './api/topic'

import reply from './api/reply'

const api = { user, topic, reply }

export default api
