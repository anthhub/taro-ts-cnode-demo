export const pagesMap = {
    index: 'pages/index/index',
    // detail: 'pages/detail/index',
    // login: 'pages/login/login',
    // user: 'pages/user/user',
    // publish: 'pages/publish/publish',
}

export type Pages = keyof typeof pagesMap
