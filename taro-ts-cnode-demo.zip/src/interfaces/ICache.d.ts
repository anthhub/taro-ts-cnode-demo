export interface IValue {
  accesstoken?: string
  [propName: string]: any
}
