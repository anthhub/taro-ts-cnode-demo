export interface IHeadProps {
    loginname?: string
    avatar_url?: string
}
