import apiObject from "../constants";
import request from "../request";
export default {
  async replyTopic(data) {
    return await request.post(apiObject.replyTopic + data.topicid + '/replies', data || {});
  },
  async upReply(data) {
    return await request.post(apiObject.upReply + data.replyid + '/ups', data || {});
  }
};