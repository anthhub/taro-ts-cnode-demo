import apiObject from "../constants";
import request from "../request";
export default {
  async checkUserToken(data) {
    return await request.post(apiObject.checkUserToken, data || {});
  },
  async getUserInfo(data) {
    return (await request.get(apiObject.getUserInfo + data.loginname, {})).data;
  }
};