import * as tslib_1 from "tslib";
import { entity, EntityBase, field } from "../../lib/decorator/entity";
let Author = class Author extends EntityBase {};
tslib_1.__decorate([field], Author.prototype, "loginname", undefined);
tslib_1.__decorate([field], Author.prototype, "avatar_url", undefined);
Author = tslib_1.__decorate([entity], Author);
export { Author };
let User = class User extends Author {
  constructor(_props) {
    super(_props);
  }
};
tslib_1.__decorate([field], User.prototype, "githubUsername", undefined);
tslib_1.__decorate([field], User.prototype, "create_at", undefined);
tslib_1.__decorate([field], User.prototype, "score", undefined);
tslib_1.__decorate([field], User.prototype, "recent_replies", undefined);
tslib_1.__decorate([field], User.prototype, "recent_topics", undefined);
User = tslib_1.__decorate([entity], User);
export { User };
let Auth = class Auth extends Author {
  constructor(_props) {
    super(_props);
  }
};
tslib_1.__decorate([field], Auth.prototype, "id", undefined);
Auth = tslib_1.__decorate([entity], Auth);
export { Auth };