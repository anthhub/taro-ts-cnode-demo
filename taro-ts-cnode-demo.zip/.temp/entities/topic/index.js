import * as tslib_1 from "tslib";
import { entity, EntityBase, field } from "../../lib/decorator/entity";
let Topic = class Topic extends EntityBase {};
tslib_1.__decorate([field], Topic.prototype, "id", undefined);
tslib_1.__decorate([field], Topic.prototype, "author_id", undefined);
tslib_1.__decorate([field], Topic.prototype, "tab", undefined);
tslib_1.__decorate([field], Topic.prototype, "content", undefined);
tslib_1.__decorate([field], Topic.prototype, "title", undefined);
tslib_1.__decorate([field], Topic.prototype, "last_reply_at", undefined);
tslib_1.__decorate([field], Topic.prototype, "good", undefined);
tslib_1.__decorate([field], Topic.prototype, "top", undefined);
tslib_1.__decorate([field], Topic.prototype, "reply_count", undefined);
tslib_1.__decorate([field], Topic.prototype, "visit_count", undefined);
tslib_1.__decorate([field], Topic.prototype, "create_at", undefined);
tslib_1.__decorate([field], Topic.prototype, "author", undefined);
Topic = tslib_1.__decorate([entity], Topic);
export { Topic };
let TopicDetail = class TopicDetail extends Topic {
  constructor(_props) {
    super(_props);
  }
};
tslib_1.__decorate([field], TopicDetail.prototype, "is_collect", undefined);
tslib_1.__decorate([field], TopicDetail.prototype, "replies", undefined);
TopicDetail = tslib_1.__decorate([entity], TopicDetail);
export { TopicDetail };
let RecentTopic = class RecentTopic extends EntityBase {};
tslib_1.__decorate([field], RecentTopic.prototype, "id", undefined);
tslib_1.__decorate([field], RecentTopic.prototype, "author", undefined);
tslib_1.__decorate([field], RecentTopic.prototype, "title", undefined);
tslib_1.__decorate([field], RecentTopic.prototype, "last_reply_at", undefined);
RecentTopic = tslib_1.__decorate([entity], RecentTopic);
export { RecentTopic };