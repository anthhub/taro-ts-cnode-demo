import { Image, Text, View } from '@tarojs/components';
import { Component } from "@tarojs/taro-h5";
import Nerv from "nervjs";
import './head.less';
class Head extends Component {
  render() {
    const { loginname, avatar_url } = this.props;
    return <View className="login-head">
                <Image className="login-head-back" src={require('../../assets/img/loginBack.jpg')} />
                <Image className="login-head-head" src={avatar_url ? avatar_url : require('../../assets/img/head.png')} />
                {loginname ? <Text className="login-head-name">{loginname}</Text> : null}
            </View>;
  }
}
export default Head;