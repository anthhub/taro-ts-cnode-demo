import Taro from '@tarojs/taro-h5';
import * as tslib_1 from "tslib";
import './panel.less';
import { myTimeToLocal } from "../../lib/utils/date";
import { Image, Text, View } from '@tarojs/components';
import { Component } from "@tarojs/taro-h5";
import Nerv from "nervjs";
import { autobind } from 'core-decorators';
let Panel = class Panel extends Component {
  toDetail(item) {
    Taro.navigateTo({ url: '/pages/detail/index?topicid=' + item.id });
  }
  render() {
    const { listData, title } = this.props;
    console.log('==========listData============');
    console.log(listData);
    console.log('====================================');
    return <View className="topic-panel">
                <View className="topic-panel-title">{title}</View>
                {listData.map(item => {
        return <View onClick={this.toDetail.bind(this, item)} className="topic-panel-list" key={item.id}>
                            <Image className="topic-panel-list-img" src={item.author.avatar_url} />
                            <Text className="topic-panel-list-title">{item.title}</Text>
                            <Text className="topic-panel-list-date">{myTimeToLocal(item.last_reply_at)}</Text>
                        </View>;
      })}
            </View>;
  }
};
Panel = tslib_1.__decorate([autobind], Panel);
export default Panel;