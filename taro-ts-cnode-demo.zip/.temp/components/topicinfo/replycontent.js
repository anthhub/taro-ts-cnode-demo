import Taro from '@tarojs/taro-h5';
import * as tslib_1 from "tslib";
import './replycontent.less';
import { autobind } from 'core-decorators';
import { Button, Textarea, View } from '@tarojs/components';
import { Component } from "@tarojs/taro-h5";
import Nerv from "nervjs";
let ReplyContent = class ReplyContent extends Component {
  constructor() {
    super(...arguments);
    this.state = { value: '' };
  }
  btnOK() {
    if (this.state.value) {
      // 父组件方法
      this.props.onOKReplyContent(this.state.value);
    } else {
      Taro.showToast({ title: '请输入评论内容', icon: 'none' });
    }
  }
  changeContent(event) {
    this.setState({ value: event.target.value });
  }
  render() {
    const { onCancelReplyContent } = this.props;
    const { value } = this.state;
    return <View className="replycontent">
                <Textarea value={value} onInput={this.changeContent} className="replycontent-text" placeholder="请输入回复内容" />
                <View className="replycontent-btngroup">
                    <Button onClick={this.btnOK} className="btn">
                        确定
                    </Button>
                    <Button onClick={onCancelReplyContent} className="btn">
                        取消
                    </Button>
                </View>
            </View>;
  }
};
ReplyContent = tslib_1.__decorate([autobind], ReplyContent);
export default ReplyContent;