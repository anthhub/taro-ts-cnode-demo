import './index.less';
import Menu from "../../components/menu/menu";
import TopicList from "../../components/topiclist/topiclist";
import { View } from '@tarojs/components';
import { Component } from "@tarojs/taro-h5";
import Nerv from "nervjs";
class Index extends Component {
  constructor() {
    super(...arguments);
  }
  render() {
    return <View className="index">
                <Menu />
                <TopicList />
            </View>;
  }
  config = {
    navigationBarTitleText: '首页'
  };

  componentDidMount() {}

  componentDidShow() {}

}
export default Index;