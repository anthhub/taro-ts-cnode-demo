import * as tslib_1 from "tslib";
import { autobind } from 'core-decorators';
import { observable, reaction, runInAction, computed, action } from 'mobx';
import { StoreExt } from "../../../lib/extent/store";
import { TopicDetailStore } from "./detail";
let TopicStore = class TopicStore extends StoreExt {
  constructor(rootStore) {
    super();
    this.detail = new TopicDetailStore(this);
    this.topicList = [];
    this.page = 0;
    this.rootStore = null;
    this.rootStore = rootStore;
    this.effects();
    this.loadList();
  }
  get tab() {
    return this.rootStore.viewStore.currentCata.key;
  }
  setPage(page) {
    this.page = page;
  }
  effects() {
    // reaction(() => this.topicList, topicList => this.setCache('topicList', topicList))
    reaction(() => this.tab, tab => this.loadList({ tab }));
    reaction(() => this.page, page => this.apendList({ tab: this.tab, page }));
  }
  async apendList(params) {
    let topicList;
    try {
      topicList = await this.api.topic.getTopics(params);
    } catch (error) {
      // topicList = await this.getCache('topicList')
    }
    runInAction(() => this.topicList = [...this.topicList, ...topicList]);
    console.log('topicList ', this.topicList);
  }
  async loadList(params) {
    let topicList;
    try {
      topicList = await this.api.topic.getTopics(params);
    } catch (error) {
      topicList = await this.getCache('topicList');
    }
    runInAction(() => this.topicList = topicList);
    console.log('topicList ', this.topicList);
  }
};
tslib_1.__decorate([observable], TopicStore.prototype, "topicList", undefined);
tslib_1.__decorate([observable], TopicStore.prototype, "page", undefined);
tslib_1.__decorate([computed], TopicStore.prototype, "tab", null);
tslib_1.__decorate([action], TopicStore.prototype, "setPage", null);
TopicStore = tslib_1.__decorate([autobind], TopicStore);
export { TopicStore };