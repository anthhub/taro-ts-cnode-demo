import * as tslib_1 from "tslib";
import { autobind } from 'core-decorators';
import { action, observable } from 'mobx';
import { StoreExt } from "../../../lib/extent/store";
let ViewStore = class ViewStore extends StoreExt {
  constructor(rootStore) {
    super();
    this.drawerVisible = false;
    this.cataData = [{ key: 'all', value: '全部' }, { key: 'good', value: '精华' }, { key: 'share', value: '分享' }, { key: 'ask', value: '问答' }, { key: 'job', value: '招聘' }, { key: 'dev', value: '客户端测试' }];
    this.currentCata = { key: 'all', value: '全部' };
    this.rootStore = rootStore;
  }
  showDrawer() {
    this.drawerVisible = true;
  }
  hideDrawer() {
    this.drawerVisible = false;
  }
  changeCata(cata) {
    this.currentCata = cata;
  }
  effects() {}
};
tslib_1.__decorate([observable], ViewStore.prototype, "drawerVisible", undefined);
tslib_1.__decorate([observable], ViewStore.prototype, "cataData", undefined);
tslib_1.__decorate([observable], ViewStore.prototype, "currentCata", undefined);
tslib_1.__decorate([action], ViewStore.prototype, "showDrawer", null);
tslib_1.__decorate([action], ViewStore.prototype, "hideDrawer", null);
tslib_1.__decorate([action], ViewStore.prototype, "changeCata", null);
ViewStore = tslib_1.__decorate([autobind], ViewStore);
export { ViewStore };