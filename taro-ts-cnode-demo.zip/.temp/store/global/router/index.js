import Taro from '@tarojs/taro-h5';
import * as tslib_1 from "tslib";
import { autobind } from 'core-decorators';
import { observable } from 'mobx';
import { StoreExt } from "../../../lib/extent/store";
import Nerv from "nervjs";
import { pagesMap } from "../../../route";
let RouterStore = class RouterStore extends StoreExt {
  constructor(rootStore) {
    super();
    this.pagesMap = pagesMap;
    this.rootStore = rootStore;
  }
  redirectTo(page, params = {}) {
    const url = this.filterPage(page, params);
    if (url) {
      Taro.redirectTo({ url });
    }
  }
  navigateTo(page, params = {}) {
    const url = this.filterPage(page, params);
    if (url) {
      Taro.navigateTo({ url });
    }
  }
  filterPage(page, params) {
    const url = this.pagesMap[page];
    if (!url) {
      Taro.showToast({ title: '页面不存在' });
      return;
    }
    if (page === 'user') {
      // 用户页面鉴权
      if (!this.rootStore.userStore.validateUser()) {
        this.navigateTo('login', params);
        return;
      }
    }
    const paramStr = (url.includes('?') ? '&' : '?') + Object.keys(params).map(key => key + '=' + params[key]).join('&');
    return '/' + url + paramStr;
  }
};
tslib_1.__decorate([observable], RouterStore.prototype, "pagesMap", undefined);
RouterStore = tslib_1.__decorate([autobind], RouterStore);
export { RouterStore };