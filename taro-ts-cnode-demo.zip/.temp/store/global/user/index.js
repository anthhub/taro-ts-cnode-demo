import * as tslib_1 from "tslib";
import { autobind } from 'core-decorators';
import { observable, runInAction } from 'mobx';
import { Auth, User } from "../../../entities/user/index";
import { StoreExt } from "../../../lib/extent/store";
let UserStore = class UserStore extends StoreExt {
  constructor(rootStore) {
    super();
    this.userAuth = new Auth();
    this.userInfo = new User();
    this.accesstoken = '5f48a3bb-eec3-4f8d-abd8-dd6bcffbda52';
    this.rootStore = rootStore;
    // this.accessUserToken && this.accessUserToken(this.accesstoken)
  }
  // 验证用户信息
  validateUser() {
    if (this.accesstoken) {
      return true;
    }
    return false;
  }
  // 获取token
  async accessUserToken(accesstoken) {
    const data = await this.api.user.checkUserToken({ accesstoken });
    if (data) {
      this.getUserInfo(data.loginname);
      runInAction(() => {
        this.accesstoken = accesstoken;
        this.userAuth = new Auth(data);
      });
      this.rootStore.routerStore.redirectTo('user');
    }
  }
  // 获取用户信息
  async getUserInfo(loginname) {
    const data = await this.api.user.getUserInfo({ loginname });
    if (data) {
      runInAction(() => this.userInfo = new User(data));
    }
  }
};
tslib_1.__decorate([observable], UserStore.prototype, "userAuth", undefined);
tslib_1.__decorate([observable], UserStore.prototype, "userInfo", undefined);
tslib_1.__decorate([observable], UserStore.prototype, "accesstoken", undefined);
UserStore = tslib_1.__decorate([autobind], UserStore);
export { UserStore };