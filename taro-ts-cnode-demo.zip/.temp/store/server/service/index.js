import * as tslib_1 from "tslib";
import { autobind } from 'core-decorators';
import { observable, computed } from 'mobx';
import { StoreExt } from "../../../lib/extent/store";
let ServiceStore = class ServiceStore extends StoreExt {
  constructor(rootStore) {
    super();
    this.rootPath = 'https://cnodejs.org/api/v1';
    this.rootStore = rootStore;
  }
  get apiObject() {
    return {
      getTopics: this.rootPath + '/topics',
      getTopicInfo: this.rootPath + '/topic/',
      checkUserToken: this.rootPath + '/accesstoken',
      getUserInfo: this.rootPath + '/user/',
      createTopic: this.rootPath + '/topics',
      replyTopic: this.rootPath + '/topic/',
      upReply: this.rootPath + '/reply/',
      updateTopic: this.rootPath + '/topics/update'
    };
  }
  effects() {}
};
tslib_1.__decorate([observable], ServiceStore.prototype, "rootPath", undefined);
tslib_1.__decorate([computed], ServiceStore.prototype, "apiObject", null);
ServiceStore = tslib_1.__decorate([autobind], ServiceStore);
export { ServiceStore };