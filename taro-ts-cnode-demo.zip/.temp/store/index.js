import * as tslib_1 from "tslib";
import { autobind } from 'core-decorators';
import { UserStore } from "./global/user/index";
import { RouterStore } from "./global/router/index";
import { ViewStore } from "./global/view/index";
import { TopicStore } from "./business/topic/index";
import { ServiceStore } from "./server/service/index";
let RootStore = class RootStore {
  constructor() {
    this.userStore = new UserStore(this);
    this.routerStore = new RouterStore(this);
    this.viewStore = new ViewStore(this);
    this.topicStore = new TopicStore(this);
    this.serviceStore = new ServiceStore(this);
  }
};
RootStore = tslib_1.__decorate([autobind], RootStore);
export { RootStore };
const rootStore = new RootStore();
const serviceStore = rootStore.serviceStore;
export { serviceStore };
export default rootStore;