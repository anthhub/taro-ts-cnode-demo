module.exports = {
  env: {
    NODE_ENV: '"production"'
  },
  defineConstants: {},
  uglify: {
    enable: true,
    config: {}
  },
  csso: {
    enable: true,
    config: {}
  },
  weapp: {},
  h5: {}
};
