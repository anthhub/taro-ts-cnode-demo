[![Build Status](https://travis-ci.org/ariesjia/taro-ts-mobx-boilerplate.svg?branch=master)](https://travis-ci.org/ariesjia/taro-ts-mobx-boilerplate)

## USEAGE
```sh
1. git clone git@github.com:ariesjia/taro-ts-mobx-boilerplate.git
2. yarn
3. // Do What You Want
```

## ICON FONT
1. put svg file to icon/svgs/
2. will auto generate font scss file to scr/generate-icon.scss (only generate woff base64 font)


