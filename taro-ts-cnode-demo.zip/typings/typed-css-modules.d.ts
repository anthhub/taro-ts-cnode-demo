declare module '*.scss' {
    const content: any;
    export = content;
}